a = 2
b = 2
if a >= b :
	print("inside")
else:
	print("outside")