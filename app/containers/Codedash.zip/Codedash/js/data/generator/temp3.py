s = "temerity"
print(s.index('r'))