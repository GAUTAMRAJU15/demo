print(8%6-5/3)
