export const MODE_SCENE_KEY = 'ModeSelectScene';
export const PLAY_SCENE_KEY = 'PlayGame';
export const PRE_SCENE_KEY = 'Preload';
export const OVER_SCENE_KEY = 'GameOver';
