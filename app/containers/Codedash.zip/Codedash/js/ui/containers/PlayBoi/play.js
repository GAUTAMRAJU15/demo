import React from 'react';

class Play extends React.Component {
  componentDidMount() {
    console.log('play mounted');
  }

  render() {
    return null;
  }
}

export default Play;
