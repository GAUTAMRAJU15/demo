import React from 'react';

class GameOver extends React.Component {
  componentDidMount() {
    console.log('game over scene init');
  }

  render() {
    return null;
  }
}

export default GameOver;
